# Servidor Flask WebRTC

Este servidor hace dos cosas:

1. Sirve la página del visor en `/`.
2. Hace de servidor de señalización WebRTC mediante Socket.IO.

## Ejecutar en local

```bash
cd webrtc_flask_server_python_client
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Instala y arranca:

```bash
pip install -r requirements.txt
python app.py
```

Abre:

```text
http://localhost:5000
```

Si el cliente Python está en otro ordenador de tu red, usa la IP del servidor:

```text
http://IP_DEL_SERVIDOR:5000
```
